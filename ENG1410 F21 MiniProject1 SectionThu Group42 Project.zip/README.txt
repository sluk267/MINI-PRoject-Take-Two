CONTENTS OF THIS FILE
---------------------

 * Introduction
 * Requirements
 * Configuration

INTRODUCTION
---------------------

 The cryptoMagic program encryption and decryption tool. Within this tool, the program can encrypt
any file with any file extension. when the program is told to encrypt a file, it will encrypt 
the specified file and give it a file extension of .crp. When the program is told to decrypt the
file, it will decrypt it and leave it with a .txt file extenion.

REQUIREMENTS
---------------------

 1. An unencrypted or encrypted file placed in the same folder as the program
 2. A need to encrypt or decrypt a file

CONFIGURATION
---------------------

 1. Move your desired file into the same folder as the program
 2. Run the program
 3. when it asks "what would you like to do: " specify where you would like to encrypt (-E) or 
    decrypt (-D)
 4. follow this with the file name and extension (if it has one) then hit enter.
 5. The program will encrypt/decrypt the file and will prompt you to hit enter to exit the program
 6. Your encrypted (.crp) or decrypted (.txt) file will be in the same folder as the program.